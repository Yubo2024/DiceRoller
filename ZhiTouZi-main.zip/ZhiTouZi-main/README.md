# ZhiTouZi
掷骰子，1-6随机数
